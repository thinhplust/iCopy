# TODO

+ before beta6  
null & fixbugs

+ before beta7  
del fav keyboard  
choose fav keyboard  
del Task info in MongoDB  

-------

+ future  
modify task info  
Support vaild folder len[28,33,72]  
Web DASHBOARD  
